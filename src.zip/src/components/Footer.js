import { Box, Button, Container, Typography, Stack, Paper, InputBase, IconButton } from '@mui/material';
import React from 'react';

export default function Footer() {

    return (
        <Box>
            <Box className="upper-footer-color">
                <Container>
                    <Box className="upper-footer">
                        <Box className="upper-footer-content">
                            <Typography className="h1">Pellentesque suscipit fringilla libero eu.</Typography>
                            <Button variant="contained" className="upper-footer-content-image" endIcon={<Box component="img" src={require("../Assets/Down.png")} />}>
                                Book Now!
                            </Button>
                        </Box>
                    </Box>
                </Container>
            </Box>

            <Box className="lower-footer-color">
                <Container>
                    <Box className="lower-footer">
                        <Box className="lower-footer-left">
                            <Box className="lower-footer-left-head">
                                <Box component="img" className="lower-footer-left-img" src={require("../Assets/Icon.png")} />
                                <Typography className="h5">Travling!</Typography>
                            </Box>
                            <Box className="lower-footer-left-body">
                                <Typography className="p">Copyright © 2020 Travling! ltd.</Typography>
                                <Typography className="p">All rights reserved</Typography>
                            </Box>
                            <Box className="lower-footer-left-foot">
                                <Stack direction="row" spacing={2}>
                                    <IconButton className="lower-footer-left-foot-icon">
                                        <Box component="img" className="lower-footer-left-foot-img" src={require("../Assets/Path3.png")} />
                                    </IconButton>
                                    <IconButton className="lower-footer-left-foot-icon">
                                        <Box component="img" className="lower-footer-left-foot-img" src={require("../Assets/Path2.png")} />
                                    </IconButton>
                                    <IconButton className="lower-footer-left-foot-icon">
                                        <Box component="img" className="lower-footer-left-foot-img" src={require("../Assets/Path4.png")} />
                                    </IconButton>
                                    <IconButton className="lower-footer-left-foot-icon">
                                        <Box component="img" className="lower-footer-left-foot-img" src={require("../Assets/Path.png")} />
                                    </IconButton>
                                </Stack>
                            </Box>
                        </Box>
                        <Box className="lower-footer-right">
                            <Box className="company1">
                                <Typography className="h5">Company</Typography>
                                <Typography className="p">About Us</Typography>
                                <Typography className="p">Blog</Typography>
                                <Typography className="p">Contact Us</Typography>
                                <Typography className="p">Pricing</Typography>
                                <Typography className="p">Testimonials</Typography>
                            </Box>
                            <Box className="company1">
                                <Typography className="h5">Support</Typography>
                                <Typography className="p">Help Center</Typography>
                                <Typography className="p">Terms of Service</Typography>
                                <Typography className="p">Legal</Typography>
                                <Typography className="p">Privacy Policy</Typography>
                                <Typography className="p">Status</Typography>
                            </Box>
                            <Box className="right-input">
                                <Typography className="h5">Stay Up to Date</Typography>
                                <Paper component="form" className="right-input-paper">
                                    <InputBase placeholder="Your email address" className="right-input-field" />
                                    <IconButton>
                                        <Box component="img" src={require("../Assets/Vector2.png")} />
                                    </IconButton>
                                </Paper>
                            </Box>
                        </Box>
                    </Box>
                </Container>
            </Box>
        </Box>
    )
}