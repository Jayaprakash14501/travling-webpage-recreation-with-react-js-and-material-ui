import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import MenuIcon from '@mui/icons-material/Menu';
import Container from '@mui/material/Container';
import Button from '@mui/material/Button';
import { Divider, Drawer, List, ListItem, Stack, Grid2 } from '@mui/material';

const pages = ['Product', 'Contact Us', 'About Us'];

export default function Header() {
  const [anchorElNav, setAnchorElNav] = React.useState(null);
  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  return (
    <Box>
      <Container>
        <AppBar className="header-contain">
          <Container className="header-contain-main">
            <Toolbar disableGutters className="header-contain-content">
              <Typography className="header-content-title">Travling!</Typography>
              <Box className="header-contain-box1">
                {pages.map((page) => (
                  <Button className="header-contain-button" key={page} onClick={handleCloseNavMenu}>{page}</Button>
                ))}
              </Box>
              <Box>
                <Button variant="contained" disableElevation className="signup-button-large">Sign Up</Button>
              </Box>
              <Box className="header-contain-box2">
                <IconButton size="large" onClick={handleOpenNavMenu} color="inherit" className="header-contain-icon-button">
                  <MenuIcon />
                </IconButton>
                <Drawer anchor="right" open={Boolean(anchorElNav)} onClose={handleCloseNavMenu}>
                  <Box>
                    <List>
                      <ListItem>
                        <Typography>Information</Typography>
                      </ListItem>
                    </List>
                    <Divider />
                    <List>
                      {pages.map((page) => (
                        <ListItem key={page} onClick={handleCloseNavMenu}>
                          <Typography>{page}</Typography>
                        </ListItem>
                      ))}
                    </List>
                    <Divider />
                    <List>
                      <ListItem>
                        <Button variant="contained" disableElevation className="signup-button-drawer">Sign Up</Button>
                      </ListItem>
                    </List>
                  </Box>
                </Drawer>
              </Box>
            </Toolbar>
          </Container>
        </AppBar>
      </Container>

      <Container>
        <Box className="content-div">
          <Grid2 container>
            <Grid2 size={{ md: 6 }}>
              <Box className="sub-content-div-para">
                <Typography className="h1">Start your journey by one click, explore beautiful world!</Typography>
                <Typography className="p">Plan and book your perfect trip with expert advice, travel tips, destination information and inspiration from us!</Typography>
                <Stack direction="row" spacing={2} className="stack-space">
                  <Button variant="contained" startIcon={<Box component="img" src={require("../Assets/google-play-png-logo-3789 1.png")} className="stack-btn-img" />} className="stack-button">
                    <Stack>
                      <Typography className="h6">Get In On</Typography>
                      <Typography className="h5">Google Play</Typography>
                    </Stack>
                  </Button>
                  <Button variant="contained" startIcon={<Box component="img" src={require("../Assets/google-play-png-logo-3789 1 (1).png")} className="stack-btn-img" />} className="stack-button">
                    <Stack>
                      <Typography className="h6">Download on the</Typography>
                      <Typography className="h5">App Store</Typography>
                    </Stack>
                  </Button>
                </Stack>
              </Box>
            </Grid2>
            <Grid2 size={{ md: 6 }}>
              <Box className="overlay-head">
                <Box component="img" src={require("../Assets/bg.png")} className="overlay1" />
                <Box component="img" src={require("../Assets/people.png")} className="overlay2" />
                <Box className="overlay3">
                  <Box component="img" src={require("../Assets/Frame.png")} className="overlay3-img" />
                </Box>
                <Box className="overlay4">
                  <Box component="img" src={require("../Assets/Vector.png")} alt="Icon" className="overlay4-img" />
                  <Typography variant="h6" className="h6">Jakarta-Bali</Typography>
                </Box>
                <Box className="overlay5">
                  <Box component="img" src={require("../Assets/Rectangle 9.png")} className="overlay5-img" />
                  <Box className="overlay5-location">
                    <Typography variant="h6" className="overlay5-location-text">Explore Labuan Bajo</Typography>
                    <Box className="overlay5-location-div">
                      <Box component="img" src={require("../Assets/Location.png")} alt="Icon" className="overlay5-location-img" />
                      <Typography variant="h6" className="h6">NTT, Indonesia</Typography>
                    </Box>
                  </Box>
                </Box>
                <Box className="overlay6">
                  <Box component="img" src={require("../Assets/rectangle.png")} className="overlay6-img" />
                  <Box className="overlay6-location">
                    <Typography variant="h6" className="overlay6-location-text">Le Hirate Hotel</Typography>
                    <Box className="overlay6-location-div">
                      <Box component="img" src={require("../Assets/Location.png")} alt="Icon" className="overlay6-location-img" />
                      <Typography variant="h6" className="h6">Flores, Indonesia</Typography>
                    </Box>
                  </Box>
                </Box>
              </Box>
            </Grid2>
          </Grid2>
        </Box>
      </Container>
    </Box>
  );
}