import React from 'react';
import { Box, Card, Typography, CardContent, Container, Stack, Button } from '@mui/material';
import rectangle1 from '../Assets/rectangle1.png';
import rectangle2 from '../Assets/rectangle2.png';
import rectangle4 from '../Assets/rectangle4.png';
import rectangle5 from '../Assets/rectangle5.png';

const cardData = [
  {
    image: rectangle5,
    location: "Mangarrai Forest",
    area: "Flores Road Trip 3D2N",
    days: "3 Days",
    price: "Rp 6.705.000",
    lang: "/orang",
  },
  {
    image: rectangle2,
    location: "Bogor",
    area: "Forrester Glamping Co Bogor",
    days: "1 Days",
    price: "Rp 1.205.000",
    lang: "/malam",
  },
  {
    image: rectangle1,
    location: "Jakarta",
    area: (<>
      Paket Tiket Pesawat
      <br />
      Jakarta Bali
    </>),
    days: "",
    price: "Rp 605.000",
    lang: "/person",
  },
  {
    image: rectangle4,
    location: "Kota Semarang",
    area: "Desa Wisata Kandri",
    days: "14 Days",
    price: "Rp 1.400.000",
    lang: "/person",
  },
];

const CustomCard = ({ image, location, area, days, price, lang }) => {

  return (
    <CardContent className="card-div">
      <Box component="img" src={image} alt={location} className="card-div-img" />
      <Box className="card-inner">
        <Box className="card-inner-location">
          <Box component="img" src={require("../Assets/Location.png")} alt={location} className="card-inner-location-img" />
          <Typography className="p">{location}</Typography>
        </Box>
        <Box className="card-inner-head">
          <Typography className="h5">{area}</Typography>
          <Typography className="h6">{days}</Typography>
        </Box>
        <Box className="card-inner-body">
          <Typography className="h5">{price}</Typography>
          <Typography className="p">{lang}</Typography>
        </Box>
      </Box>
    </CardContent>

  );
};

export default function Cardbox() {

  return (
    <Box>
      <Container>
        <Box className="card-main">
          <Box className="card-main-head">
            <Typography className="h5">Popular Destinations</Typography>
            <Typography className="p">Vacations to make your experience enjoyable in Indonesia!</Typography>
            <Box className="card-main-outer">
              {cardData.map((card, index) => (
                <Card variant="text" className="card-outer-shape" key={index}>
                  <CustomCard image={card.image} location={card.location} area={card.area} days={card.days} price={card.price} lang={card.lang} />
                </Card>
              ))}
            </Box>
          </Box>
        </Box>
      </Container>

      <Container>
        <Box className="product-head">
          <Box className="product-image">
            <Box component="img" src={require("../Assets/illustrasi.png")} className="product-image-img" />
          </Box>
          <Box className="product-content">
            <Box className="product-content-outer">
              <Typography className="h5">Why Choose Us</Typography>
              <Typography className="p">Enjoy different experiences in every place you visit and discover new and affordable adventures of course.</Typography>
              <Stack className="product-content-stack">
                <Box className="product-content-inner">
                  <Box component="img" src={require("../Assets/Group 84.png")} className="product-content-inner-img" />
                  <Box className="product-content-inner-body">
                    <Typography className="h5">Flight Ticket</Typography>
                    <Typography className="p">Vitae donec pellentesque a aliquam et ultricies auctor.</Typography>
                  </Box>
                </Box>
                <Box className="product-content-inner">
                  <Box component="img" src={require("../Assets/hotel.png")} className="product-content-inner-img" />
                  <Box className="product-content-inner-body">
                    <Typography className="h5">Accomodation</Typography>
                    <Typography className="p">Vitae donec pellentesque a aliquam et ultricies auctor.</Typography>
                  </Box>
                </Box>
                <Box className="product-content-inner">
                  <Box component="img" src={require("../Assets/Group.png")} className="product-content-inner-img" />
                  <Box className="product-content-inner-body">
                    <Typography className="h5">Packaged Tour</Typography>
                    <Typography className="p">Vitae donec pellentesque a aliquam et ultricies auctor.</Typography>
                  </Box>
                </Box>
                <Box>
                  <Button variant="text" className="product-content-inner-button" endIcon={<Box component="img" src={require("../Assets/Vector (1).png")} />}>
                    Another Product
                  </Button>
                </Box>
              </Stack>
            </Box>
          </Box>
        </Box>
      </Container>
    </Box>
  );
}
