import { Box } from '@mui/material';
import './App.css';
import './components/style.css'
import Header from './components/Header';
import Cardbox from './components/Cardbox';
import Footer from './components/Footer';

function App() {

  return (
    <Box className="overall">
      <Box className="back-img">
        <Box component="img" src={require("./Assets/linecross.png")} className="back-image" />
      </Box>
      <Box className="header-color">
        <Header />
      </Box>
      <Box className="body-color">
        <Cardbox />
      </Box>
      <Box>
        <Footer />
      </Box>
    </Box>
  );
}

export default App;
